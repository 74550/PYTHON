n=int(input("inserisci numero: "))
l=[]
l[1:n-1]=1
l[0]=0
l[n]=0
print(l)

parola=input("inserisci parola: ")
print(parola[::2])
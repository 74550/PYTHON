n=int(input("inserisci numero: "))
l=[]
k=0
v=0
for elemento in n: 
    l[k]=v
    k=k+1
    v=v+1
print(l)
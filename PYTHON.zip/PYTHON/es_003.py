prima = 12
seconda = 14

print({prima}-{seconda})

lavoro = prima
prima = seconda
seconda = lavoro
print({prima}-{seconda})
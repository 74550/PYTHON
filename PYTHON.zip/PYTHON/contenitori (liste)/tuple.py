#tuple simili alle liste ma immutabili
punto=(1.5,3.6)
print(f"la cordinata x del punto è {punto[0]}")
triangolo=[(1.5,3.6),(-1.0,0.0),(5.1,4.3)]
print(f"la cordinata y del secondo vertice è {triangolo[1][1]}")
num1=int(input("dimmi un primo numero: "))
num2=int(input("dimmi un secondo numero: "))
l=[(num1*num1)+(num2*num2),(num1+num2)*(num1+num2),(num1*num1)-(num2*num2),(num1-num2)*(num1-num2)]
print(l)
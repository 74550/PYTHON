lista_voti=[8,7,6,5,3,9,2]
print(lista_voti[1:-1])
lista_voti[3]=10
print(lista_voti[:3])
l1=[1,2,3]
l2=[4,5]
l3=l1+l2
print(l3)
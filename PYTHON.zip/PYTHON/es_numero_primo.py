n = int(input("inserisci un numero maggiore di 0: "))
i = 1
primo = True
while i <= n and primo == True :  #ciclo finchè i < n e numero primo è vero
    if (i != 1 and i != n):      #i diverso da 1 e n  
        if(n%i == 0):
            primo = False        #se il numero diviso per i da resto 0, non è primo

if(primo == True): 
    print("numero primo")
else:
    print("numero non primo")



l=["ciao",print,1,3.24]

for indice, elemento in enumerate(l):
    print(indice,elemento)

indice=0
for elemento in l:
    print(indice,elemento)
    indice=indice+1
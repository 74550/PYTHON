d={1:"Abello",2:"Armando"}
d2={"Abello":[8,9,7,10], "Armando":[5,3,9,10]}
print(d[2])
print(d2["Abello"])
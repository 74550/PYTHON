nome=input("dimmi un nome: ")
print(nome[::-1])
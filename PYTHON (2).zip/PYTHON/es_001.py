intero = 11
stringa = "parola"
reale = 2.3
booleano = False

print(intero)
print(stringa)
print(reale)
print(booleano)

print(type(intero))
print(type(stringa))
print(type(reale))
print(type(booleano))
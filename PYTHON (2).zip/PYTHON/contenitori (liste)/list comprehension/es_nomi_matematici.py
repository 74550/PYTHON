l=["Gauss","Conway","Eulero","Hilbert"]
l_gh=[nome for nome in l if nome[0]=="G"or nome[0]=="H"]
print (l_gh)
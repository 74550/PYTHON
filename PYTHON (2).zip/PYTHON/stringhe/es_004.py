parola=input("dimmi una parola: ")
print (parola[1:-1])
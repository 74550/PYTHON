stringa=("inserisci parola:")
print(stringa[::2])
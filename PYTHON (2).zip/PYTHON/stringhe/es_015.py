from operator import length_hint


nome=input("dimmi un nome: ")
print(nome[0]+"*"*(len(nome)-1))
print(nome/nome)
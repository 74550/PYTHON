rubrica={"Tasso":3516388329, "Armando":3703522116, "Cano":3913301879, "Cristian":3802049509}
print(rubrica["Armando"])
rubrica["Serra"]=3403214567
print(rubrica)
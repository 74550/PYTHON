a=int(input("Inserisci il primo numero: "))
b=int(input("Inserisci il secondo numero: "))

medie={"MediaAr":(a+b)/2, "MediaGeo":((a*b)**0.5)}
print(medie)
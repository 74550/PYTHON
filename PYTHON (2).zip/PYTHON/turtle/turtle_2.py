from time import sleep
from turtle import Turtle, Screen
from time import sleep
tartaruga = Turtle ()
sfondo = Screen ()
sfondo.colormode (255)
R = 255
G= 0
B = 0
tartaruga.color ( (R, G, B))
tartaruga.forward (100)
tartaruga.right (120)
tartaruga. forward (100)
tartaruga.right (120)
tartaruga. forward (100)
sleep(5)
from time import sleep
from turtle import Turtle, Screen
tartaruga = Turtle ()
sfondo = Screen ()
tartaruga. forward (100)
tartaruga.right (90)
tartaruga. forward (100)
tartaruga.left (90)
tartaruga.backward (100)
tartaruga.left (90)
tartaruga.forward(100)
sleep(5)
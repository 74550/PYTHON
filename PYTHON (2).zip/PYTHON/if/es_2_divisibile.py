n=int(input("scrivi un numero: "))
if n%2==0:
    print("divisibile per 2")
if n%3==0:
        print("divisibile per 3")
if n%5==0:
    print("divisibile per 5")

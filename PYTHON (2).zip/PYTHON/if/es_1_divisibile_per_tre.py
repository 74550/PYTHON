n=int(input("scrivi un numero: "))
if n%3==0:
    print("divisibile")
else:
    print("non divisibile")